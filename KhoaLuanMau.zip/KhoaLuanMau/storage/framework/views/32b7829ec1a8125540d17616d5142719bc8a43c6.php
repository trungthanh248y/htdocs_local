<?php $__env->startComponent('mail::message'); ?>
# Metting thành công

Cảm ơn bạn đã đặt đơn hẹn tại website của chúng tôi. Nhân viên sẽ liên hệ với bạn sơm nhất có thể


Thanks,<br>
Website tìm phòng trường Đại học Lâm Nghiệp
<?php echo $__env->renderComponent(); ?>

<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/email/user/newusermeeting.blade.php */ ?>