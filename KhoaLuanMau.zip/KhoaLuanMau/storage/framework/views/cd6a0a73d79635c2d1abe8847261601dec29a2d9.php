<?php $__env->startSection('content'); ?>
    <table class="table">
        <?php if(session('mess')): ?>
            <p class="alert alert-success"><?php echo e(session('mess')); ?></p>
        <?php endif; ?>
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Items</th>
            <th scope="col"><a href="<?php echo e(Route('addItem')); ?>" class="btn btn-success">ADD</a></th>
        </tr>
        </thead>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
            <tr>
                <th scope="row"><?php echo e($item->id); ?></th>
                <td><?php echo e($item->item); ?></td>
                <td>
                    <a href="<?php echo e(Route('editItem',$item->id)); ?>" class="btn btn-info">Edit</a>

                    <form action="<?php echo e(Route('deleteItem' )); ?>" method="POST">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                        <input type="submit" name="btn_sub" class="btn btn-danger" value="DELETE">
                    </form>
                </td>
            </tr>
            </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/Items/select.blade.php */ ?>