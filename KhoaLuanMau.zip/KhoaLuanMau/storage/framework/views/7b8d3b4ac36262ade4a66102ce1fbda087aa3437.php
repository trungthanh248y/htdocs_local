










































<div>
    <?php dd($posts);?>
    <div class="media">
        <div class="media-left">--}}
            <img class="media-object" src="<?php echo e(asset('images/'.$posts->image)); ?>" alt="small-img-3">
            </div>
            <div class="media-body">
                <h3 class="media-heading">
                    <a href="#"><?php echo e($posts->title); ?></a>
                </h3>
                <p><?php echo e($posts->acreage); ?></p>
                <h5><?php echo e($posts->describe); ?></h5>
            </div>
    </div>
</div>
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/PostUser/PostHot.blade.php */ ?>