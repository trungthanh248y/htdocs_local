<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e(Route('indexPostRomm')); ?>" class="btn btn-success">BACK HOME</a>
                <h1>EDIT POST</h1>
                <?php if(session('mess')): ?>
                    <p class="alert alert-success"><?php echo e(session('mess')); ?></p>
                <?php endif; ?>
                <?php if(count($errors)!=0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="alert alert-danger"><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <form action="<?php echo e(Route('editPostRoomSubmit',$rooms['id'])); ?>" method="POST" class="form-group" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="text">title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($rooms['title']); ?>">
                    <label for="text">address</label>
                    <input type="text" name="address" class="form-control" value="<?php echo e($rooms['address']); ?>">
                    <label for="text">acreage</label>
                    <input type="text" name="acreage" class="form-control" value="<?php echo e($rooms['acreage']); ?>">
                    <label for="text">price</label>
                    <input type="text" name="describe" class="form-control" value="<?php echo e($rooms['describe']); ?>">




                    <hr class="mb-4">
                    <label for="text">Items</label>
                    <hr class="mb-4">
                    <div class="row">
                        <?php $__currentLoopData = $temp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-4">
                                <p><lable><input type="checkbox" name="item[]" value="<?php echo e($item->id); ?>"
                                        <?php if(in_array($item->id,$sub_temps)): ?><?php echo e("checked='checked'"); ?>

                                                <?php endif; ?>
                                        ><?php echo e($item->item); ?></lable></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <hr class="mb-4">

                    <label for="exampleFormControlTextarea1">Content</label>
                    <textarea name="content" class="form-control" id="exampleFormControlTextarea1" rows="3"><?php echo e($rooms['content']); ?></textarea>
                    <img class="img-rounded corners" style="width: 300px; height:200px" src="<?php echo e(asset('images/'.$rooms['image'])); ?>" alt="" ><br>
                    Image: <input type="file" name="image" value="Image"><br>
                    <input type="submit" name="btn_sub" class="btn btn-light" value="Update Post">
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/PostRoom/edit.blade.php */ ?>