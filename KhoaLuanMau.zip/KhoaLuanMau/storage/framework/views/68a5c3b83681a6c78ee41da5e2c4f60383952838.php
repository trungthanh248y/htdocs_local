<header>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    </header>
    <body>
        <div>
            <div class="collapse bg-dark" id="navbarHeader">
                <div class="container">
                    <div class="row">
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-8 col-md-7 py-4">
                                <p class="text-muted"><?php echo e($order->username); ?></p>
                                <p class="text-muted"><?php echo e($order->phone); ?></p>
                            </div>
                            <div class="col-sm-4 offset-md-1 py-4">
                                <p class="text-white"><?php echo e($order->created_at); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="navbar navbar-dark bg-dark shadow-sm">
                <div class="container d-flex justify-content-between">
                    <a href="javascript:;" class="navbar-brand d-flex align-items-center">
                    <span class="row">
                    <h1 class="col-md">Total orders Year: <?php echo e(count($orderMonth)); ?></h1> 
                    <h1 class="col-md">Total orders month: <?php echo e(count($orderMonth)); ?></h1>
                    <h1 class="col-md">Total orders date: <?php echo e(count($orderDate)); ?></h1>
                    </span>
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation">
                        <h1>Lish</h1>
                    </button>
                </div>
            </div>
        </div>
    </body>
    
    
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/Statistic/order.blade.php */ ?>