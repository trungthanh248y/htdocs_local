<?php $__env->startSection('content'); ?>
    <table class="table">
        <?php if(session('mess')): ?>
            <p class="alert alert-success"><?php echo e(session('mess')); ?></p>
        <?php endif; ?>
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">title</th>
            <th scope="col">address</th>
            <th scope="col">acreage</th>
            <th scope="col">price</th>
            <th scope="col">item</th>
            <th scope="col">content</th>
            <th scope="col">Image</th>
            <th scope="col"><a href="<?php echo e(Route('addRoom')); ?>" class="btn btn-success">ADD</a></th>
        </tr>
        </thead>
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
            <tr>
                <th scope="row"><?php echo e($room->id); ?></th>
                <td><?php echo e($room->title); ?></td>
                <td><?php echo e($room->address); ?></td>
                <td><?php echo e($room->acreage); ?></td>
                <td><?php echo e($room->describe); ?></td>
                <td>
                    <?php $items=\App\Room::find($room->id)->items()->get()?>

                    <div class="row">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6">
                        <?php echo e($item->item); ?>

                            <hr class="mb-4">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </td>
                <td>
                    <?php if(strlen($room->content)>50): ?>
                        <p><?php echo e(substr($room->content,0,50)."..."); ?></p>
                    <?php else: ?>
                        <p><?php echo e($room->content); ?></p>
                    <?php endif; ?>
                </td>
                <td>
                    <img class="img-rounded corners" style="width: 300px; height:100px" src="<?php echo e(asset('images/'.$room->image)); ?>" alt="">
                </td>
                <td>
                    <a href="<?php echo e(Route('editRoom',$room->id)); ?>" class="btn btn-info">Edit</a>

                    <form action="<?php echo e(Route('deleteRoom' )); ?>" method="POST">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="hidden" name="id" value="<?php echo e($room->id); ?>">
                        <input type="submit" name="btn_sub" class="btn btn-danger" value="DELETE">
                    </form>
                </td>
            </tr>
            </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/rooms/select.blade.php */ ?>