<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="<?php echo e(Route('Post')); ?>" method="POST" class="form-group" enctype="multipart/form-data">
                    <label for="text">title</label>
                    <input type="text" name="title" class="form-control">
                    <label for="text">Content</label>
                    <input type="text" name="title" class="form-control-plaintext">
                    <input type="file" name="image" value="Image">
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/posts/home.blade.php */ ?>