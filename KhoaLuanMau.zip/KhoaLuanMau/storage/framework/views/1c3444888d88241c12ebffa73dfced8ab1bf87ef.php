<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-xs-12">
                <div class="row">
                    <div class="col-md-6">
                        <img style="height:340px;width:100%" src="<?php echo e(asset('images/'.$posts->image)); ?>" alt="Not Image">
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                        <div class="col-md-6">
                        <img style="width: 150px;height: 150px" src="http://123nhadatviet.com/files/properties/2019/2/28/images/20190228_030408_1600480_0.jpg">
                        <hr class="mb-4">
                        <img style="width: 150px;height: 150px" src="http://123nhadatviet.com/files/properties/2019/2/28/images/20190228_030408_1600480_2.jpg">
                        </div>
                        <div class="col-md-6">
                        <img style="width: 150px;height: 150px" src="https://www.chotot.com/kinhnghiem/wp-content/uploads/2016/11/Nhung-dieu-tan-sinh-vien-can-biet-khi-thue-phong-tro.jpg">
                        <hr class="mb-4">
                        <img style="width: 150px;height: 150px" src="http://123nhadatviet.com/files/properties/2019/2/28/images/20190228_030408_1600480_1.jpg">
                        </div>
                        </div>
                    </div>
                </div>
                <hr class="mb-4">
                <div class="row">
                    <div class="col-sm-8">
                    <p>Title: <b><?php echo e($posts->title); ?></b></p>
                    </div>
                    <hr class="mb-4">
                    <div class="col-sm-4">
                        <?php if($posts->sale!=null): ?>
                            <strike>Price: <b><?php echo e($posts->describe); ?> VN đồng</b></strike>

                            <p>Sale: <b><?php echo e($posts->sale); ?> VN đồng</b></p>

                        <?php else: ?>
                            <p>Price: <b><?php echo e($posts->describe); ?> VN đồng</b></p>
                        <?php endif; ?>

                    <p>Acreage: <b><?php echo e($posts->acreage); ?> m2</b></p>
                    </div>
                    <div class="col-md-12">
                        <p><p class="font-weight-bold">Address:</p> <?php echo e($posts->address); ?></p>
                    </div>
                </div>
                <hr class="mb-4">
                <p><p class="font-weight-bold">Content:</p> <?php echo e($posts->content); ?></p>
                <hr class="mb-4">
                <lable><p class="font-weight-bold">Item: </p></lable>
                <div class="row">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4">
                            <p><lable><input type="checkbox" name="item[]"
                                    <?php if(in_array($item->id,$sub_item)): ?><?php echo e("checked='checked'"); ?>

                                    <?php endif; ?>
                                    disabled="disabled"><?php echo e($item->item); ?></lable></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <hr class="mb-4">

                <div class="mymap" style="width: 90%;margin-left: 65px ">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4562.089127010306!2d105.57472175017492!3d20.91095222555259!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3134456c69afbb4d%3A0xaa4e3f4c05b31119!2zVHLGsOG7nW5nIMSQ4bqhaSBo4buNYyBMw6JtIG5naGnhu4dw!5e0!3m2!1svi!2s!4v1556766043982!5m2!1svi!2s" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>

                <hr class="mb-4">

            <?php if(Auth::check()): ?>
                <div>
                    <a href="<?php echo e(Route('order',$posts->id)); ?>" class="btn btn-info">Meeting appointment</a>
                </div>
                <?php endif; ?>
                <hr class="mb-4">
                <?php if(Auth::check()): ?>
                    <div class="well">
                        <h4>Comment....</h4>
                        <?php if($errors): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="alert alert-danger"><?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <form action="<?php echo e(Route('commnet',$posts->id)); ?>" method="post">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="form-group">
                            <textarea name="comment" class="form-control" rows="3" placeholder="
                            <?php if(session('mess')): ?>
                            <?php echo e(session('mess')); ?>

                            <?php endif; ?>
                                    "></textarea>
                            </div>
                            <input type="submit" value="Comment" class="btn btn-light">
                        </form>
                        <hr class="mb-6">
                    </div>
                <?php endif; ?>
                <div class="bg-white container">
                <div>
                    <?php if($comments!=null): ?>
                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e(\App\User::find($comment->id_user)->name); ?> <span class="text-muted"><?php echo e($comment->created_at); ?></span> </p>
                            <p><?php echo e($comment->comment); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                </div>

            </div>
            <div class="col-lg-4 col-md-4 col-xs-12">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card flex-row mb-2 shadow-sm h-md-150">
                        <div class="card-body d-flex flex-column align-items-start">
                            <div class="media">
                                <div class="media-left">
                                    <div class="col-auto d-none d-lg-block">
                                        <a href="<?php echo e(Route('postUser',$event->id)); ?>">
                                        <img style="height:150px;width:150px" src="<?php echo e(asset('images/'.$event['image'])); ?>" alt="Not Image">
                                        </a>
                                    </div>
                                </div>
                                <div class="media-body">



                                    <p>acreage: <?php echo e($event['acreage']); ?> m2</p>


                                    <?php if($posts->sale!=null): ?>
                                        <strike>Price: <b><?php echo e($posts->describe); ?> VN đồng</b></strike>

                                        <p>Sale: <b><?php echo e($posts->sale); ?> VN đồng</b></p>

                                    <?php else: ?>
                                        <p>Price: <b><?php echo e($posts->describe); ?> VN đồng</b></p>
                                    <?php endif; ?>

                                </div>
                            </div>
                            <hr class="mb-4">
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>



            <main role="main" class="col-md-12 ml-sm-auto col-lg-12 px-4">
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php if(count($species)>2): ?>

                            <div class="carousel-item active">
                            <div class="row col-auto">
                                <?php for($j=0;$j<3;$j++): ?>
                                    <div class="col-4">
                                                    <div class="card flex-row mb-2 shadow-sm h-md-150">
                                                        <div class="card-body d-flex flex-column align-items-start">
                                                            
                                                            <div class="row">

                                                                

                                                                <div class="col-auto d-none d-lg-block">
                                                                    <center>
                                                                        <img style="height:180px;width:230px" src="<?php echo e(asset('images/'.$species[$j]->image)); ?>" alt="Not Image">
                                                                    </center>
                                                                </div>

                                                                <div class="col p-4 d-flex flex-column position-static">

                                                                    <?php if($species[$j]->sale!=null): ?>
                                                                        <strike>Price: <b><?php echo e($species[$j]->describe); ?> VN đồng</b></strike>

                                                                        <p>Sale: <b><?php echo e($species[$j]->sale); ?> VN đồng</b></p>

                                                                    <?php else: ?>
                                                                        <p>Price: <b><?php echo e($species[$j]->describe); ?> VN đồng</b></p>
                                                                    <?php endif; ?>


                                                                    <h3 class="mb-0"><?php echo e($species[$j]->title); ?></h3>
                                                                    <div class="mb-1 text-muted">Nov <?php echo e($species[$j]->id); ?></div>
                                                                    <?php if(strlen($species[$j]->content)>50): ?>
                                                                        <p class="card-text mb-auto"><?php echo e(substr($species[$j]->content,0,50)."..."); ?></p>
                                                                    <?php else: ?>
                                                                        <p class="card-text mb-auto"><?php echo e($species[$j]->content); ?></p>
                                                                    <?php endif; ?>
                                                                    <a href="<?php echo e(Route('postUser',$species[$j]->id)); ?>" class="stretched-link">Continue reading</a>
                                                                </div>

                                                                <div style="clear: both"></div>
                                                            </div>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                <?php endfor; ?>
                            </div>
                            </div>
                            <?php for($t=3;$t<count($species)-2;$t++): ?>

                                <div class="carousel-item">
                                <div class="row col-auto">

                                    <div class="col-4">
                                        <div class="card flex-row mb-2 shadow-sm h-md-150">
                                            <div class="card-body d-flex flex-column align-items-start">
                                                
                                                <div class="row">

                                                    

                                                    <div class="col-auto d-none d-lg-block">
                                                        <center>
                                                            <img style="height:180px;width:230px" src="<?php echo e(asset('images/'.$species[$t]->image)); ?>" alt="Not Image">
                                                        </center>
                                                    </div>

                                                    <div class="col p-4 d-flex flex-column position-static">

                                                        <?php if($species[$t]->sale!=null): ?>
                                                            <strike>Price: <b><?php echo e($species[$t]->describe); ?> VN đồng</b></strike>

                                                            <p>Sale: <b><?php echo e($species[$t]->sale); ?> VN đồng</b></p>

                                                        <?php else: ?>
                                                            <p>Price: <b><?php echo e($species[$t]->describe); ?> VN đồng</b></p>
                                                        <?php endif; ?>

                                                        <h3 class="mb-0"><?php echo e($species[$t]->title); ?></h3>
                                                        <div class="mb-1 text-muted">Nov <?php echo e($species[$t]->id); ?></div>
                                                        <?php if(strlen($species[$t]->content)>50): ?>
                                                            <p class="card-text mb-auto"><?php echo e(substr($species[$t]->content,0,50)."..."); ?></p>
                                                        <?php else: ?>
                                                            <p class="card-text mb-auto"><?php echo e($species[$t]->content); ?></p>
                                                        <?php endif; ?>
                                                        <a href="<?php echo e(Route('postUser',$species[$t]->id)); ?>" class="stretched-link">Continue reading</a>
                                                    </div>

                                                    <div style="clear: both"></div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>

                                    <?php if($t<count($species)-2): ?>



                                            <div class="col-4">
                                                <div class="card flex-row mb-2 shadow-sm h-md-150">
                                                    <div class="card-body d-flex flex-column align-items-start">
                                                        
                                                        <div class="row">

                                                            

                                                            <div class="col-auto d-none d-lg-block">
                                                                <center>
                                                                    <img style="height:180px;width:230px" src="<?php echo e(asset('images/'.$species[$t+1]->image)); ?>" alt="Not Image">
                                                                </center>
                                                            </div>

                                                            <div class="col p-4 d-flex flex-column position-static">

                                                                <?php if($species[$t+1]->sale!=null): ?>
                                                                    <strike>Price: <b><?php echo e($species[$t+1]->describe); ?> VN đồng</b></strike>

                                                                    <p>Sale: <b><?php echo e($species[$t+1]->sale); ?> VN đồng</b></p>

                                                                <?php else: ?>
                                                                    <p>Price: <b><?php echo e($species[$t+1]->describe); ?> VN đồng</b></p>
                                                                <?php endif; ?>

                                                                <h3 class="mb-0"><?php echo e($species[$t+1]->title); ?></h3>
                                                                <div class="mb-1 text-muted">Nov <?php echo e($species[$t+1]->id); ?></div>
                                                                <?php if(strlen($species[$t+1]->content)>50): ?>
                                                                    <p class="card-text mb-auto"><?php echo e(substr($species[$t+1]->content,0,50)."..."); ?></p>
                                                                <?php else: ?>
                                                                    <p class="card-text mb-auto"><?php echo e($species[$t+1]->content); ?></p>
                                                                <?php endif; ?>
                                                                <a href="<?php echo e(Route('postUser',$species[$t+1]->id)); ?>" class="stretched-link">Continue reading</a>
                                                            </div>

                                                            <div style="clear: both"></div>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                            </div>



                                            <div class="col-4">
                                                <div class="card flex-row mb-2 shadow-sm h-md-150">
                                                    <div class="card-body d-flex flex-column align-items-start">
                                                        
                                                        <div class="row">

                                                            

                                                            <div class="col-auto d-none d-lg-block">
                                                                <center>
                                                                    <img style="height:180px;width:230px" src="<?php echo e(asset('images/'.$species[$t+2]->image)); ?>" alt="Not Image">
                                                                </center>
                                                            </div>

                                                            <div class="col p-4 d-flex flex-column position-static">

                                                                <?php if($species[$t+2]->sale!=null): ?>
                                                                    <strike>Price: <b><?php echo e($species[$t+2]->describe); ?> VN đồng</b></strike>

                                                                    <p>Sale: <b><?php echo e($species[$t+2]->sale); ?> VN đồng</b></p>

                                                                <?php else: ?>
                                                                    <p>Price: <b><?php echo e($species[$t+2]->describe); ?> VN đồng</b></p>
                                                                <?php endif; ?>

                                                                <h3 class="mb-0"><?php echo e($species[$t+2]->title); ?></h3>
                                                                <div class="mb-1 text-muted">Nov <?php echo e($species[$t+2]->id); ?></div>
                                                                <?php if(strlen($species[$t+2]->content)>50): ?>
                                                                    <p class="card-text mb-auto"><?php echo e(substr($species[$t+2]->content,0,50)."..."); ?></p>
                                                                <?php else: ?>
                                                                    <p class="card-text mb-auto"><?php echo e($species[$t+2]->content); ?></p>
                                                                <?php endif; ?>
                                                                <a href="<?php echo e(Route('postUser',$species[$t+2]->id)); ?>" class="stretched-link">Continue reading</a>
                                                            </div>

                                                            <div style="clear: both"></div>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                    <?php endif; ?>
                                </div>
                                </div>
                            <?php endfor; ?>
                        <?php else: ?>
                        <div class="row col-auto">
                            <?php for($i=0;$i<count($species);$i++): ?>
                                <div class="col-4">
                                <div class="card flex-row mb-2 shadow-sm h-md-150">
                                    <div class="card-body d-flex flex-column align-items-start">
                                        
                                        <div class="row">

                                            

                                            <div class="col-auto d-none d-lg-block">
                                                <center>
                                                    <img style="height:180px;width:230px" src="<?php echo e(asset('images/'.$species[$i]->image)); ?>" alt="Not Image">
                                                </center>
                                            </div>

                                            <div class="col p-4 d-flex flex-column position-static">

                                                <?php if($species[$i]->sale!=null): ?>
                                                    <strike>Price: <b><?php echo e($species[$i]->describe); ?> VN đồng</b></strike>

                                                    <p>Sale: <b><?php echo e($species[$i]->sale); ?> VN đồng</b></p>

                                                <?php else: ?>
                                                    <p>Price: <b><?php echo e($species[$i]->describe); ?> VN đồng</b></p>
                                                <?php endif; ?>

                                                <h3 class="mb-0"><?php echo e($species[$i]->title); ?></h3>
                                                <div class="mb-1 text-muted">Nov <?php echo e($species[$i]->id); ?></div>
                                                <?php if(strlen($species[$i]->content)>50): ?>
                                                    <p class="card-text mb-auto"><?php echo e(substr($species[$i]->content,0,50)."..."); ?></p>
                                                <?php else: ?>
                                                    <p class="card-text mb-auto"><?php echo e($species[$i]->content); ?></p>
                                                <?php endif; ?>
                                                <a href="<?php echo e(Route('postUser',$species[$i]->id)); ?>" class="stretched-link">Continue reading</a>
                                            </div>

                                            <div style="clear: both"></div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <?php endfor; ?>
                        </div>
                        <?php endif; ?>
                    </div>

                    <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </main>

    </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/PostUser/userPostHome.blade.php */ ?>