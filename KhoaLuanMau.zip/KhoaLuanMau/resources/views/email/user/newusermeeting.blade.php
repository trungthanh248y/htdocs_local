@component('mail::message')
# Metting thành công

Cảm ơn bạn đã đặt đơn hẹn tại website của chúng tôi. Nhân viên sẽ liên hệ với bạn sơm nhất có thể


Thanks,<br>
Website tìm phòng trường Đại học Lâm Nghiệp
@endcomponent
