<div class="show">
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12">
        <div class="card flex-row mb-2 shadow-sm h-md-150">
            <div class="card-body d-flex flex-column align-items-start">
                
                <div class="row">

                    

                    <div class="col-lg-4 col-md-4 col-xs-12" style="float: left">
                        <div class="col-auto d-none d-lg-block">
                            <center>
                                <img style="height:180px;width:230px" src="<?php echo e(asset('images/'.$post->image)); ?>" alt="Not Image">
                            </center>
                        </div>
                    </div>

                    <div class="col-lg-8 col-md-8 col-xs-12">
                        <div class="col p-4 d-flex flex-column position-static">
                            <strong class="d-inline-block mb-2 text-primary"><?php echo e($post->describe); ?></strong>
                            <h3 class="mb-0"><?php echo e($post->title); ?></h3>
                            <div class="mb-1 text-muted">Nov <?php echo e($post->id); ?></div>
                            <?php if(strlen($post->content)>50): ?>
                                <p class="card-text mb-auto"><?php echo e(substr($post->content,0,50)."..."); ?></p>
                            <?php else: ?>
                                <p class="card-text mb-auto"><?php echo e($post->content); ?></p>
                            <?php endif; ?>
                            <a href="<?php echo e(Route('postUser',$post->id)); ?>" class="stretched-link">Continue reading</a>
                        </div>
                    </div>

                    <div style="clear: both"></div>
                </div>
                
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="col-sm-6 col-sm-offset-3">
    <?php echo e($posts->links()); ?>

</div>
</div>
<script type="text/javascript">
    $(document).on('click','.pagination a', function(e) {
        e.preventDefault();
        var page = $(this).attr('href').split('page=')[1];
        getPosts(page);
    });
    function getPosts(page)
    {
        $.ajax({
            type: "GET",
            url: '/welcomePost',
            data:{page:page},
            dataType: 'html',

            success:function (data) {
                $('.show').html(data);
            }
        })
    }
</script>
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/PostUser/welcome.blade.php */ ?>