<?php $__env->startSection('content'); ?>
    <?php if(session('mess')): ?>
        <p class="alert alert-success"><?php echo e(session('mess')); ?></p>
    <?php endif; ?>
    <form action="<?php echo e(Route('checkEvent')); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="submit" value="Check Event" name="btn_sub" class="btn btn-success">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-xs-12">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">title</th>
                        <th scope="col">Events</th>
                        <th scope="col">address</th>
                        <th scope="col">acreage</th>
                        <th scope="col">price</th>
                        <th scope="col">sale</th>
                        <th scope="col">item</th>
                        <th scope="col">content</th>
                        <th scope="col">Image</th>
                        <th scope="col"><a href="<?php echo e(Route('addPost')); ?>" class="btn btn-success">ADD</a></th>
                    </tr>
                    </thead>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                        <tr>
                            <th scope="row"><?php echo e($post['id']); ?></th>
                            <td><?php echo e($post['title']); ?></td>
                            <td><input type="checkbox" name="postCheck[]" value="<?php echo e($post['id']); ?>"></td>
                            <td><?php echo e($post['address']); ?></td>
                            <td><?php echo e($post['acreage']); ?></td>
                            <td><?php echo e($post['describe']); ?></td>
                            <td><?php echo e($post['sale']); ?></td>

                            <td>
                                <?php $items=\App\Post::find($post->id)->items()->get()?>

                                <div class="row">
                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-6">
                                            <?php echo e($item->item); ?>

                                            <hr class="mb-4">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </td>

                            <td>
                                <?php if(strlen($post->content)>50): ?>
                                    <p><?php echo e(substr($post->content,0,50)."..."); ?></p>
                                <?php else: ?>
                                    <p><?php echo e($post->content); ?></p>
                                <?php endif; ?>
                            </td>
                            <td>
                                <img class="img-rounded corners" style="width: 300px; height:100px" src="<?php echo e(asset('images/'.$post['image'])); ?>" alt="">
                            </td>
                            <td>
                                <a href="<?php echo e(Route('getEdittPost',$post['id'])); ?>" class="btn btn-info">Edit</a>

                                <form action="<?php echo e(Route('deletePost' )); ?>" method="POST">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="hidden" name="id" value="<?php echo e($post['id']); ?>">
                                    <input type="submit" name="btn_sub" class="btn btn-danger" value="Delete">
                                </form>
                            </td>
                        </tr>
                        </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <div class="col-lg-4 col-md-4 col-xs-12">
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">name</th>
                        <th scope="col">Posts</th>
                        <th scope="col">content</th>
                        <th scope="col">start time</th>
                        <th scope="col">end time</th>
                        <th scope="col"><a href="<?php echo e(Route('addEvent')); ?>" class="btn btn-success">ADD</a></th>
                    </tr>
                    </thead>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                        <tr>
                            <th scope="row"><?php echo e($event['id']); ?></th>
                            <td><?php echo e($event['name']); ?></td>
                            <td><input type="checkbox" name="eventCheck[]" value="<?php echo e($event['id']); ?>"></td>
                            <td><?php echo e($event['start_time']); ?></td>
                            <td><?php echo e($event['end_time']); ?></td>
                            <td>
                                <?php if(strlen($event->content)>50): ?>
                                    <p><?php echo e(substr($event->content,0,50)."..."); ?></p>
                                <?php else: ?>
                                    <p><?php echo e($event->content); ?></p>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(Route('getEdittEvent',$event->id)); ?>" class="btn btn-info">Edit</a>

                                <form action="<?php echo e(Route('deleteEvent')); ?>" method="POST">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <input type="hidden" name="id" value="<?php echo e($event['id']); ?>">
                                    <input type="submit" name="btn_sub" class="btn btn-danger" value="Delete">
                                </form>
                            </td>
                        </tr>
                        </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/posts/select.blade.php */ ?>