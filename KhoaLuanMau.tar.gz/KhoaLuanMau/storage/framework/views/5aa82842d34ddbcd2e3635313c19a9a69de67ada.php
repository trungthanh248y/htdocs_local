<html>
    <head>
        <title>Web tro</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    </head>
    <body>
        <div class="container"><?php echo $__env->yieldContent('content'); ?></div>
    </body>
</html>














<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/master.blade.php */ ?>