<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row">
    <div class="col-lg-8 col-md-8 col-xs-12">
        <?php if(session('mess')): ?>
            <p class="alert alert-success"><?php echo e(session('mess')); ?></p>
        <?php endif; ?>
        <form action="<?php echo e(Route('orderPost',$posts->id)); ?>" method="post">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <h1 class="text-center">Meeting appointment</h1>
            <div>
                <lable>User Name</lable>
                <input type="text" name="username" class="form-control" value="<?php echo e(Auth::user()->name); ?>" readonly>
            </div>
            <div>
                <lable>Phone</lable>
                <input type="text" name="phone" class="form-control">
            </div>
            <div>
                <lable>Appointment Time</lable>
                <br>

                <select name="time" class="btn btn-sm btn-outline-info dropdown-toggle">
                    <option value="7">7h</option>
                    <option value="8">8h</option>
                    <option value="9">9h</option>
                    <option value="10">10h</option>
                    <option value="11">11h</option>
                    <option value="14">14h</option>
                    <option value="15">15h</option>
                    <option value="16">16h</option>
                    <option value="17">17h</option>
                </select>
            </div>
            <div>
                <lable>title</lable>
                <input type="text" name="title" class="form-control" value="<?php echo e($posts->title); ?>" readonly>
            </div>
            <div>
                <lable>Price</lable>
                <input type="text" name="describe" class="form-control" value="<?php if($posts->sale==0): ?><?php echo e($posts->describe); ?><?php else: ?><?php echo e($posts->sale); ?><?php endif; ?>" readonly>
            </div>
            <hr class="mb-4">
            <input type="submit" value="Meeting" class="btn btn-info">
        </form>
    </div>
    <div class="col-lg-4 col-md-4 col-xs-12">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card flex-row mb-2 shadow-sm h-md-150">
            <div class="card-body d-flex flex-column align-items-start">
                <div class="media">
                    <div class="media-left">
                        <div class="col-auto d-none d-lg-block">
                            <a href="<?php echo e(Route('postUser',$event->id)); ?>">
                            <img style="height:150px;width:150px" src="<?php echo e(asset('images/'.$event['image'])); ?>" alt="Not Image">
                            </a>
                        </div>
                    </div>
                    <div class="media-body">



                        <p>acreage: <?php echo e($event['acreage']); ?> m2</p>

                        <?php if($posts->sale!=null): ?>
                            <strike>Price: <b><?php echo e($posts->describe); ?> VN đồng</b></strike>

                            <p>Sale: <b><?php echo e($posts->sale); ?> VN đồng</b></p>

                        <?php else: ?>
                            <p>Price: <b><?php echo e($posts->describe); ?> VN đồng</b></p>
                        <?php endif; ?>

                    </div>
                </div>
                <hr class="mb-2">
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/PostUser/UserOrder.blade.php */ ?>