<?php echo e($slot); ?>


<?php /* /opt/lampp/htdocs/KhoaLuanMau/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php */ ?>