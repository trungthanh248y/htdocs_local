
<html>

<head>
    <link rel="canonical" href="https://getbootstrap.com/docs/4.3/examples/dashboard/">
</head>
<h1> Đặt đơn hẹn thành công </h1>

Cảm ơn bạn <strong><?php echo e($meeting->username); ?></strong> đã đặt đơn hẹn tại website của chúng tôi. Nhân viên sẽ liên hệ với bạn qua số <strong><?php echo e($meeting->phone); ?></strong> sơm nhất có thể
<h3>Thời gian hẹn của bạn là: <?php echo e($meeting->time); ?> Giời</h3>
<h3>Khu trọ của bạn là: <?php echo e($meeting->title); ?></h3>
<h3>Giá phòng thuê là: <?php echo e($meeting->describe); ?> vnđ</h3>

Cảm ơn bạn đã sử dụng dịch vụ của chúng tôi<br>
<h2>Website tìm phòng trường Đại học Lâm Nghiệp</h2>

</html>


<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/email/user/newusermeeting.blade.php */ ?>