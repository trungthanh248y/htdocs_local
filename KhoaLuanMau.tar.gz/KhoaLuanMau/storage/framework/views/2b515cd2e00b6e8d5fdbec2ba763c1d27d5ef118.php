<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Web tim phong</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <div class="col-4 pt-1">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        Home
                    </a>
                    <?php if(Auth::check()&&Auth::user()->role!='users'): ?>
                        <a class="navbar-brand" href="<?php echo e(url('/home')); ?>">Manage</a>
                    <?php endif; ?>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                </div>
                <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <?php if(Auth::check()&&Auth::user()->role=='host'): ?>
                                        <a href="<?php echo e(Route('selectRoom')); ?>" class="dropdown-item">Room</a>
                                    <?php endif; ?>
                                    <?php if(Auth::check()&&Auth::user()->role=='admin'): ?>
                                        <a href="<?php echo e(Route('selectPost')); ?>" class="dropdown-item">POST</a>
                                        <a href="<?php echo e(Route('chatAdmin')); ?>" class="dropdown-item">Reply the message</a>
                                        <a href="<?php echo e(Route('indexMeeting')); ?>" class="dropdown-item">Meeting</a>
                                        <a href="<?php echo e(Route('indexPostRomm')); ?>" class="dropdown-item">Post Room</a>
                                        <a href="<?php echo e(Route('chart')); ?>" class="dropdown-item">Statistic</a>
                                        <a href="<?php echo e(Route('itemIndex')); ?>" class="dropdown-item">Items</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(Route('chatUser')); ?>" class="dropdown-item">Chat</a>
                                        <a href="#" class="dropdown-item">Personal Information</a>
                                    <?php endif; ?>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
                </nav>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>

<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/layouts/app.blade.php */ ?>