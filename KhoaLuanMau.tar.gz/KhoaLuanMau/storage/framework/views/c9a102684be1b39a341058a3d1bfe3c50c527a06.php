<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e(Route('indexMeeting')); ?>" class="btn btn-success">BACK HOME</a>
                <h1>EDIT MEETING</h1>
                <?php if(session('mess')): ?>
                    <p class="alert alert-success"><?php echo e(session('mess')); ?></p>
                <?php endif; ?>
                <?php if(count($errors)!=0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="alert alert-danger"><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <form action="<?php echo e(Route('editPostMeetingSubmit',$meetings->id)); ?>" method="POST" class="form-group" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label for="text">username</label>
                    <input type="text" name="username" class="form-control" value="<?php echo e($meetings->username); ?>">
                    <label for="text">phone</label>
                    <input type="text" name="phone" class="form-control" value="<?php echo e($meetings->phone); ?>">
                    <label for="text">time</label>
                    <input type="text" name="time" class="form-control" value="<?php echo e($meetings->time); ?>">
                    <label for="text">title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($meetings->title); ?>">
                    <label for="text">Price</label>
                    <input type="text" name="describe" class="form-control" value="<?php echo e($meetings->describe); ?>">
                    <input type="submit" name="btn_sub" class="btn btn-light">
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/Meeting/edit.blade.php */ ?>