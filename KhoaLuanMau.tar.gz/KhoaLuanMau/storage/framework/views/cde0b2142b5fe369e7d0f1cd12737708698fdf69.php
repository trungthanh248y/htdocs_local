<?php $__env->startSection('content'); ?>
<table class="table">
    <?php if(session('mess')): ?>
        <p class="alert alert-success"><?php echo e(session('mess')); ?></p>
    <?php endif; ?>
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">username</th>
        <th scope="col">phone</th>
        <th scope="col">time</th>
        <th scope="col">title</th>
        <th scope="col">Price</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <?php $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tbody>
        <tr>
          <th scope="row"><?php echo e($meeting['id']); ?></th>
          <td><?php echo e($meeting['username']); ?></td>
          <td><?php echo e($meeting['phone']); ?></td>
          <td><?php echo e($meeting['time']); ?></td>
          <td><?php echo e($meeting['title']); ?></td>
          <td><?php echo e($meeting['describe']); ?></td>
          <td>
              <a href="<?php echo e(Route('editMeeting',$meeting->id)); ?>" class="btn btn-info">Edit</a>

              <form action="<?php echo e(Route('deletePostMeeting')); ?>" method="POST">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="id" value="<?php echo e($meeting->id); ?>">
                <input type="submit" name="btn_sub" class="btn btn-danger" value="Delete">
              </form>
          </td>
        </tr>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-12">

        <?php if(count($meetings)>=6): ?>
            <div class="col-sm-6 col-sm-offset-3">
                <?php echo e($meetings->links()); ?>

            </div>
        <?php else: ?>

        <?php endif; ?>
    </div>
  </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /opt/lampp/htdocs/KhoaLuanMau/resources/views/Meeting/select.blade.php */ ?>