<?php

use Faker\Generator as Faker;

$factory->define(App\Temp::class, function (Faker $faker) {
    return [
        //
//        'item'=>$faker->name,
    ];
});
